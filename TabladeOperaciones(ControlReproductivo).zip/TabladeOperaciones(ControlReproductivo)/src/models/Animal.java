/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package models;

import java.sql.Date;

/**
 *
 * @author Tk
 */
public class Animal {

    int id;
    String nro;
    String vacia;
    String preñada;
    String pp;
    String meses;
    Date fechaprob;
    String observaciones;

    public Animal(int id, String nro, String vacia, String preñada, String pp, String meses, Date fechaprob, String observaciones) {
        this.id = id;
        this.nro = nro;
        this.vacia = vacia;
        this.preñada = preñada;
        this.pp = pp;
        this.meses = meses;
        this.fechaprob = fechaprob;
        this.observaciones = observaciones;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
    
    public String getNro() {
        return nro;
    }

    public void setNro(String nro) {
        this.nro = nro;
    }
    
    public String getVacia() {
        return vacia;
    }

    public void setVacia(String vacia) {
        this.vacia = vacia;
    }

    public String getPreñada() {
        return preñada;
    }

    public void setPreñada(String preñada) {
        this.preñada = preñada;
    }

    public String getPP() {
        return pp;
    }

    public void setPP(String pp) {
        this.pp = pp;
    }

    public String getMeses() {
        return meses;
    }

    public void setMeses(String meses) {
        this.meses = meses;
    }

    public Date getFechaprob() {
        return fechaprob;
    }

    public void setFechaprob(Date fechaprob) {
        this.fechaprob = fechaprob;
    }

    public String getObservaciones() {
        return observaciones;
    }

    public void setObservaciones(String observaciones) {
        this.observaciones = observaciones;
    }

}
