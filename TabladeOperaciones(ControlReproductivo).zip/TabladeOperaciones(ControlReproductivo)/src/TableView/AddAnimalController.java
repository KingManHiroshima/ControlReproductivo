/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TableView;

import Helpers.DbConnect;
import Models.Animal;
import com.jfoenix.controls.JFXDatePicker;
import com.jfoenix.controls.JFXTextField;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.input.MouseEvent;

/**
 * FXML Controller class
 *
 * @author Tk
 */
public class AddAnimalController implements Initializable {

    @FXML
    private JFXTextField nroFld;
    @FXML
    private JFXTextField vaciaFld;
    @FXML
    private JFXTextField preñadaFld;
    @FXML
    private JFXTextField ppFld;
    @FXML
    private JFXTextField mesesFld;
    @FXML
    private JFXDatePicker fechaprobFld;
    @FXML
    private JFXTextField observacionesFld;

    String query = null;
    Connection connection = null;
    ResultSet resultSet = null;
    PreparedStatement preparedStatement = null;
    Animal animal = null;
    private boolean update;
    int animalId;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }

    @FXML
    private void save(MouseEvent event) {
        connection = DbConnect.getConnect();
        String nro = nroFld.getText();
        String vacia = vaciaFld.getText();
        String preñada = preñadaFld.getText();
        String pp = ppFld.getText();
        String meses = mesesFld.getText();
        String fechaprob = String.valueOf(fechaprobFld.getValue());
        String observaciones = observacionesFld.getText();

        if (nro.isEmpty() || vacia.isEmpty() || preñada.isEmpty() || pp.isEmpty() || meses.isEmpty() || fechaprob.isEmpty() || observaciones.isEmpty()) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setHeaderText(null);
            alert.setContentText("Por favor llene toda la data");
            alert.showAndWait();

        } else {
            getQuery();
            insert();
            clean();
        }
    }

    @FXML
    private void clean() {
        nroFld.setText(null);
        vaciaFld.setText(null);
        preñadaFld.setText(null);
        ppFld.setText(null);
        mesesFld.setText(null);
        fechaprobFld.setValue(null);
        observacionesFld.setText(null);

    }

    private void getQuery() {
        if (update == false) {
            query = "INSERT INTO `item`(`nro.delanimal`, `vacia`, `preñada`, `p.p.`, `meses`, `fechaprobablep`, `observaciones`) VALUES (?,?,?,?,?,?,?)";
        } else {
            query = "UPDATE `item` SET "
                    + "`nro.delanimal`=?,"
                    + "`vacia`=?,"
                    + "`preñada`=?,"
                    + "`p.p.`=?,"
                    + "`meses`=?,"
                    + "`fechaprobablep`=?,"
                    + "`observaciones`=? WHERE id = '" + animalId + "'";
        }
    }

    private void insert() {
        try {

            preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, nroFld.getText());
            preparedStatement.setString(2, vaciaFld.getText());
            preparedStatement.setString(3, preñadaFld.getText());
            preparedStatement.setString(4, ppFld.getText());
            preparedStatement.setString(5, mesesFld.getText());
            preparedStatement.setString(6, String.valueOf(fechaprobFld.getValue()));
            preparedStatement.setString(7, observacionesFld.getText());
            preparedStatement.execute();

        } catch (SQLException ex) {
            Logger.getLogger(AddAnimalController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    void setUpdate(boolean b) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    void setTextField(int nro, String vacia, String preñada, String pp, String meses, LocalDate toLocalDate, String observaciones)
    {

        animalId = nro;
        vaciaFld.setText(vacia);
        preñadaFld.setText(preñada);
        ppFld.setText(pp);
        mesesFld.setText(meses);
        fechaprobFld.setValue(toLocalDate);
        observacionesFld.setText(observaciones);
        {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }

    }

    }
