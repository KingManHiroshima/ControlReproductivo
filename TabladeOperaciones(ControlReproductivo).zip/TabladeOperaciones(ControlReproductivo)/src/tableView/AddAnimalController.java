/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tableView;

import com.jfoenix.controls.JFXDatePicker;
import com.jfoenix.controls.JFXTextField;
import helpers.DbConnect;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.input.MouseEvent;
import models.Animal;

/**
 * FXML Controller class
 *
 * @author Tk
 */
public class AddAnimalController implements Initializable {

    @FXML
    private JFXTextField nroFld;
    @FXML
    private JFXTextField vaciaFld;
    @FXML
    private JFXTextField preñadaFld;
    @FXML
    private JFXTextField ppFld;
    @FXML
    private JFXTextField mesesFld;
    @FXML
    private JFXDatePicker fechaFld;
    @FXML
    private JFXTextField observacionesFld;

    String query = null;
    Connection connection = null;
    ResultSet resultSet = null;
    PreparedStatement preparedStatement;
    Animal animal = null;
    private boolean update;
    int animalId;
    
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void save(MouseEvent event) {
        connection = DbConnect.getConnect();
        String nro = nroFld.getText();
        String vacia = vaciaFld.getText();
        String preñada = preñadaFld.getText();
        String pp = ppFld.getText();
        String meses = mesesFld.getText();
        String fecha = String.valueOf(fechaFld.getValue());
        String observaciones = observacionesFld.getText();

        if (nro.isEmpty() || vacia.isEmpty() || preñada.isEmpty() || pp.isEmpty() || meses.isEmpty() || fecha.isEmpty() || observaciones.isEmpty()) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setHeaderText(null);
            alert.setContentText("Por favor llene toda la data");
            alert.showAndWait();

        } else {
            getQuery();
            insert();
            clean();
        }
    }

    @FXML
    private void clean() {
        nroFld.setText(null);
        vaciaFld.setText(null);
        preñadaFld.setText(null);
        ppFld.setText(null);
        mesesFld.setText(null);
        fechaFld.setValue(null);
        observacionesFld.setText(null);
        
    }
    
    private void getQuery() {

        if (update == false) {

            query = "INSERT INTO `animal`(`nro.delanimal`, `vacia`, `preñada`, `pp`, `meses`, `fechaprobable`, `observaciones`) VALUES (?,?,?,?,?,?,?)";

        } else {
            query = "UPDATE `animal` SET "
                    + "`nro.delanimal`=?,"
                    + "`vacia`=?,"
                    + "`preñada`=?,"
                    + "`pp`=?,"
                    + "`meses`=?,"
                    + "`fechaprobable`=?,"
                    + "`observaciones`= ? WHERE id = '" + animalId + "'";
        }
    }
    private void insert() {

        try {

            preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, nroFld.getText());
            preparedStatement.setString(2, vaciaFld.getText());
            preparedStatement.setString(3, preñadaFld.getText());
            preparedStatement.setString(4, ppFld.getText());
            preparedStatement.setString(5, mesesFld.getText());
            preparedStatement.setString(6, String.valueOf(fechaFld.getValue()));
            preparedStatement.setString(7, observacionesFld.getText());
            preparedStatement.execute();

        } catch (SQLException ex) {
            Logger.getLogger(AddAnimalController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    void setTextField(int id, String nro, String vacia, String preñada, String pp, String meses, LocalDate toLocalDate,
             String observaciones) {

        animalId = id;
        nroFld.setText(nro);
        vaciaFld.setText(vacia);
        preñadaFld.setText(preñada);
        ppFld.setText(pp);
        mesesFld.setText(meses);
        fechaFld.setValue(toLocalDate);
        observacionesFld.setText(observaciones);
    }

    void setUpdate(boolean b) {
        this.update = b;

    }
}
