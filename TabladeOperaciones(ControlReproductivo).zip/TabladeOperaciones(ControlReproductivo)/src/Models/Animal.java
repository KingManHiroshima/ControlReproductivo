/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Models;

import java.sql.Date;

/**
 *
 * @author Tk
 */
public class Animal {

    int nro;
    String vacia;
    String preñada;
    String pp;
    String meses;
    Date fechaprob;
    String observaciones;
    

    public Animal(int nro , String vacia, String preñada, String pp, String meses, Date fechaprob, String observaciones) {
        this.nro = nro;
        this.vacia = vacia;
        this.preñada = preñada;
        this.pp = pp;
        this.meses = meses;
        this.fechaprob = fechaprob;
        this.observaciones = observaciones;
    }

    public Animal(int aInt) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public int getNro() {
        return nro;
    }

    public void setNro(int nro) {
        this.nro = nro;
    }

    public String getvacia() {
        return vacia;
    }

    public void setvacia(String vacia) {
        this.vacia = vacia;
    }

    public String getpreñada() {
        return preñada;
    }

    public void setpreñada(String preñada) {
        this.preñada = preñada;
    }

    public String getpp() {
        return pp;
    }

    public void setpp(String pp) {
        this.pp = pp;
    }

    public String getmeses() {
        return meses;
    }

    public void setmeses(String meses) {
        this.meses = meses;
    }
    
    public Date getFechaprob() {
        return fechaprob;
    }

    public void setFechaprob(Date fechaprob) {
        this.fechaprob = fechaprob;
    }

    public String getobservaciones() {
        return observaciones;
    }

    public void setobservaciones(String observaciones) {
        this.observaciones = observaciones;
    }

    public String getId() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}
